package web.controlevacinacao.validation.util;

public enum AttributesRelation {
	EQUAL, DIFFERENT, GREATERTHAN, LESSTHAN, GREATEROREQUAL, LESSOREQUAL
}
