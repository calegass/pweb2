package web.primeiroprojetospring.model;

public interface Tecnico {
	
	public String getExercicioDiario();

	public String getSorteDiaria();
}
