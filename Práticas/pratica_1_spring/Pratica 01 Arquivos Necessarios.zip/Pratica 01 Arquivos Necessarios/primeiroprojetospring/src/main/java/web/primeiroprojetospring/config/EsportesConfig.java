package web.primeiroprojetospring.config;

public class EsportesConfig {

}
