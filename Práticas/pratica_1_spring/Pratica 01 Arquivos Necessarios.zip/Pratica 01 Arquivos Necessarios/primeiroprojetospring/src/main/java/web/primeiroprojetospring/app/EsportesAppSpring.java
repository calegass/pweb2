package web.primeiroprojetospring.app;

public class EsportesAppSpring {
    public static void main(String[] args) {

    }
}
