package web.primeiroprojetospring.app;

public class EsportesAppNormal {
    public static void main(String[] args) {
        
    }
}
