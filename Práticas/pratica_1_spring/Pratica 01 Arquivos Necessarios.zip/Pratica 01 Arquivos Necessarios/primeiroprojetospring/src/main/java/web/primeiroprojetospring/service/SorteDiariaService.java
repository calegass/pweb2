package web.primeiroprojetospring.service;

public interface SorteDiariaService {

	public String getSorteDiaria();
	
}
