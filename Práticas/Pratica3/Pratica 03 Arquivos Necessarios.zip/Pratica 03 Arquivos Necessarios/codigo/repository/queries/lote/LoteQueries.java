package web.controlevacinacao.repository.queries.lote;

public interface LoteQueries {

	//List<Lote> pesquisar(LoteFilter filtro);
	
}
