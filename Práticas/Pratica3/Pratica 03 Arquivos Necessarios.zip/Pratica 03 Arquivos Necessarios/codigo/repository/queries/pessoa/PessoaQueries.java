package web.controlevacinacao.repository.queries.pessoa;

import web.controlevacinacao.model.Pessoa;

public interface PessoaQueries {

	Pessoa buscarComProfissao(String cpf);
	
}
